# Python Functions

This repository contains seven beginner-level Python programs that use user-defined functions.

## Programs

1. Largest of two numbers
2. Factorial of a number
3. Even or odd
4. Prime number
5. Sum of two numbers
6. Fibonacci series
7. Palindrome check

## Requirements

- Python 3
- Visual Studio Code (recommended)
- Git (for version control)

## How to run

Open this folder in Visual Studio Code. Open the terminal and run a file, for example:

```bash
python 01_largest_number.py
```

Replace the filename with any of the other `.py` files to run another program.

## Author

Tahosin Islam

## Note

These are practice examples for learning Python functions. Check that the program topics match your teacher's assigned list before submitting them as coursework.
